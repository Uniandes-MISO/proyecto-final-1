﻿namespace SportApp.Model
{
    public class Usuario
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int TipoIdentificacion { get; set; }
        public long NumeroIdentificacion { get; set; }
        public string Genero { get; set; }
        public int Edad { get; set; }
        public decimal Peso { get; set; }
        public decimal Altura { get; set; }
        public DateTime FechaCreacion { get; set; }

    }
}