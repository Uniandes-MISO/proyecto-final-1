﻿using SportApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportApp.Data.Repository
{
    public interface IUsuarioRepository
    {
        Task<bool> CrearUsuario(Usuario usuario);
        Task<IEnumerable<Usuario>> ObtenerTodosUsuarios();
    }
}
