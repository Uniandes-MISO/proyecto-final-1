﻿using Dapper;
using Npgsql;
using SportApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportApp.Data.Repository
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private PostgreSQLConfiguration _postgreSQLConfiguration;

        public UsuarioRepository(PostgreSQLConfiguration postgreSQLConfiguration)
        {
            _postgreSQLConfiguration = postgreSQLConfiguration;
        }

        protected NpgsqlConnection dbConnection()
        {
            return new NpgsqlConnection(_postgreSQLConfiguration.ConnectionString);
        }

        public async Task<bool> CrearUsuario(Usuario usuario)
        {
            var db = dbConnection();

            var sql = @"
                       INSERT INTO public.usuario (nombre,apellido,tipoidentificacion,numeroidentificacion,genero,edad,peso,altura,fechacreacion)
                       VALUES(@nombre,@apellido,@tipoidentificacion,@numeroidentificacion,@genero,@edad,@peso,@altura,@fechacreacion)";
            var Fechacreacion = DateTime.Now;

            var result = await db.ExecuteAsync(sql, new { usuario.Nombre,usuario.Apellido,usuario.TipoIdentificacion,usuario.NumeroIdentificacion,usuario.Genero,
                                                          usuario.Edad,usuario.Peso,usuario.Altura,Fechacreacion});

            return result > 0;
        }

        public async Task<IEnumerable<Usuario>> ObtenerTodosUsuarios()
        {
            var db = dbConnection();

            var sql = @"
                      SELECT id,nombre,apellido,tipoidentificacion,numeroidentificacion,genero,edad,peso,altura,fechacreacion
                      FROM public.usuario";

            return await db.QueryAsync<Usuario>(sql, new { });
        }
    }
}
