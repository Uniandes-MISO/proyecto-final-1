﻿using Microsoft.AspNetCore.Mvc;
using SportApp.Data.Repository;
using SportApp.Model;

namespace SportApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : Controller
    {

        private readonly IUsuarioRepository _usuarioRepository;

        public UsuarioController(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        [HttpGet]
        public async Task<IActionResult> ObtenerTodosUsuarios()
        {
            return Ok(await _usuarioRepository.ObtenerTodosUsuarios());
        }

        [HttpPost]
        public async Task<IActionResult> CrearUsuario([FromBody] Usuario usuario)
        {
            if (usuario == null)
                return BadRequest();

            if(!ModelState.IsValid)
                return BadRequest(ModelState);

            var registro = await _usuarioRepository.CrearUsuario(usuario);

            return Created("Creado", registro);
        }

    }
}
