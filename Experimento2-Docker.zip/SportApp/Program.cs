using SportApp.Data;
using SportApp.Data.Repository;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// Conexion BD
var provider = builder.Services.BuildServiceProvider();
var configuration = provider.GetService<IConfiguration>();
var postgresSQLConnectionConfiguration = new PostgreSQLConfiguration(configuration.GetValue<string>("postgresSQLConnection"));
builder.Services.AddSingleton(postgresSQLConnectionConfiguration);

builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>();


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();


builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
